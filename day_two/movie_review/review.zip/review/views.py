from django.forms.forms import Form
from django.shortcuts import get_object_or_404, redirect, render
from .models import *
from django.http import HttpResponse, request
from .forms import *
from .templates import *
from .forms2 import SearchForm
from .forms3 import RatingForm
from django.db.models import Avg

# from .forms4 import ProjectSettings
# Create your views here.


def index(request):
    movies = Movie.objects.all()

    form = MovieForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        print(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/review/')
    else:
        context = {'movies': movies, 'form': form}
    return render(request, 'review/ui.html', context)


def award_movie(request):
    movies = Award.objects.all()

    form = AwardForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        print(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/review/')
    else:
        context = {'movies': movies, 'form': form}
    return render(request, 'review/awards.html', context)


def artist_movie(request):
    movies = Artist.objects.all()

    form = ArtistForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        print(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/review/')
    else:
        context = {'movies': movies, 'form': form}
    return render(request, 'review/artist.html', context)


def search_movie(request):
    form = SearchForm(request.POST or None)
    queryset = None
    if request.method == 'POST':
        queryset = Movie.objects.filter(name__icontains=form['name'].value()) or Movie.objects.filter(artists__aname=form['name'].value())
        print(queryset)
    context = {
        "form": form,
        "queryset": queryset}
    return render(request, 'review/search.html', context)


def rate_movie(request):
    rate = Rating.objects.all()

    """
    function to rate Movies
    """

    # if request.method == "POST":
    #     rate_form = RatingForm(request.POST)
    #     # print(type(rate_form))
    #     if rate_form.is_valid():
    #         form_object =  rate_form.save(commit=False)

    #     messages.success(request, "Rated Successfully !")
    #     # TODO -> Average rating Logic
    #     return redirect(reverse('rate_movie'))
    # else:
    #     messages.error(request, "Error While Rating ")
    #     return redirect(reverse('rate_movie'))

    # else:
    #     rate_form = RatingForm()
    form = RatingForm(request.POST or None, request.FILES or None)
    rate = None
    if request.method == 'POST':
        if form.is_valid():

            # print(form)
            new = form.save(commit=False)
            # print(new)
            new.movie_rating = form.cleaned_data.get('movie_rating')
            new.movie = form.cleaned_data['movie']
            filtered_data = Rating.objects.filter(
                movie_rating=new.movie_rating, movie=new.movie)
            if filtered_data.count() >= 1:
                rate_obj = filtered_data.get()
                rate_obj.votes += 1
                rate_obj.save()
                rate_obj.movie.save()
                if rate_obj.votes >= 1:
                    Rating.objects.aggregate(Avg('votes'))
                    print(Rating.objects.aggregate(Avg('votes')))
                    total = Rating.objects.aggregate(Avg('votes'))
                    
            else:
                new.votes = 1
                new.save()
                new.movie.save()
            return redirect('/review/')
    else:
        context = {'form': form, 'rate': rate}
    return render(request, 'review/rating.html', context)

def top(request):
    avrage=Movie.objects.all().order_by('avg_rating')
    
    return render(request,'review/order.html',{"context":avrage})
def down(request):
    avrage=Movie.objects.all().order_by('-avg_rating')
    
    return render(request,'review/order.html',{"context1":avrage})